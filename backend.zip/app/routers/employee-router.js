module.exports = function (app) {
    const employeeController = require("../controllers/employee-controller");
    app.get("/EMPLOYEE", employeeController.getList);
    app.post("/EMPLOYEE", employeeController.insert);

    app.get("/EMPLOYEE/:NAME/:BU", employeeController.detail2)
    app.get("/EMPLOYEENAME/:NAME",employeeController.detail1)
    app.get("/EMPLOYEE/:IDEMP",employeeController.detailid)
    app.delete("/EMPLOYEE/:ID", employeeController.delete)
    app.put("/EMPLOYEE/:ID", employeeController.update)
    app.put("/EMPLOYEE/TIMEDRAW/:ID", employeeController.updatetimedraw)

    const luckynumberController = require("../controllers/luckynumber-controller");
    app.get("/LUCKYNUMBER", luckynumberController.getList);
    app.get("/LUCKYNUMBER/getlucky", luckynumberController.getListlucky);
    app.post("/LUCKYNUMBER", luckynumberController.insert);

    
    app.get("/LUCKYNUMBER/:ID",luckynumberController.detail)
    app.delete("/LUCKYNUMBER/:ID", luckynumberController.delete)
    app.put("/LUCKYNUMBER/:ID", luckynumberController.update)
  };
  