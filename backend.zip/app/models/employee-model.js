  const db = require("../common/connect");
const eMPLOYEE = (EMPLOYEE) => {
    this.ID = EMPLOYEE.ID;
    this.IDEMP = EMPLOYEE.IDEMP;
    this.NAME = EMPLOYEE.NAME;
    this.BU = EMPLOYEE.BU;
    this.TIMEDRAW = EMPLOYEE.TIMEDRAW;
    this.RESULT = EMPLOYEE.RESULT;
  this.GIFT = EMPLOYEE.GIFT;
  };

  eMPLOYEE.getById = (id, callback) => {
    const sqlString = "SELECT * FROM EMPLOYEE WHERE ID = ? ";
    db.query(sqlString, id, (err, result) => {
      if (err) {
        return callback(err);
      }
      callback(result);
    });
  };
  
eMPLOYEE.getList = (callback) => {
    const sqlString = "SELECT * FROM EMPLOYEE ";
    db.query(sqlString, (err, result) => {
      if (err) {
        return callback(err);
      }
      callback(result);
    });
  };
  
eMPLOYEE.add = (newEMPLOYEE, callBack) => {
    const sqlString = "INSERT INTO EMPLOYEE SET ?";
    db.query(sqlString, newEMPLOYEE, (err, res) => {
      if (err) {
        callBack(err);
        return;
      }
      callBack({ id: res.insertId, ...newEMPLOYEE });
    });
  };
  
eMPLOYEE.update = (employ, id, callBack) => {
    const sqlString = "UPDATE EMPLOYEE SET ? WHERE ID = ?";
  db.query(sqlString, [employ, id], (err, res) => {
      if (err) {
        callBack(err);
        return;
      }
      callBack("cập nhật nhân viên với id = " + id + " thành công");
    });
  };
  
eMPLOYEE.delete = (id, callBack) => {
    db.query(`DELETE FROM EMPLOYEE WHERE id = ?`, id, (err, res) => {
      if (err) {
        callBack(err);
        return;
      }
      callBack("xóa nhân viên với id = " + id + " thành công");
    });
  };
  
module.exports = eMPLOYEE;