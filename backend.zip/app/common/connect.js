var mysql = require('mysql');
var db = mysql.createConnection({
  host: "103.75.186.15",
  user: "sbpnknyqhosting_admin",
  password: "P@sswrd13042000",
  database: "sbpnknyqhosting_Nestlewebapp"
});
module.exports = db;