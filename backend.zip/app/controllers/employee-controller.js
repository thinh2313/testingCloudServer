const db = require("../common/connect");

module.exports = {
  getList: (req, res) => {
    const sqlString = "SELECT * FROM EMPLOYEE ";
    db.query(sqlString, (err, result) => {
      if (err) throw err
      res.json(result)
    });
  },

  detailid: (req, res) => {
    const id = req.params.IDEMP;
    const sqlString = "SELECT * FROM EMPLOYEE WHERE IDEMP = ? ";
    db.query(sqlString, id, (err, result) => {
      if (err) throw err
      res.json(result)

    });
  },
detail1: (req, res) => {
    const id = req.params.NAME;
    const sqlString = "SELECT * FROM EMPLOYEE WHERE NAME = ? ";
    db.query(sqlString, id, (err, result) => {
      if (err) throw err
      res.json(result)

    });
  },

  detail2: (req, res) => {
    const name = req.params.NAME;
    const phone = req.params.BU;
    const sqlString = "SELECT * FROM EMPLOYEE where NAME = ? AND BU = ? ";
    db.query(sqlString, [name,phone], (err, result) => {
      if (err) throw err
      res.json(result);
    });
  },



  insert: (req, res) => {
    //   const emp = req.body;
    //   const sqlString = "INSERT INTO EMPLOYEE SET ?";
    //   db.query(sqlString, emp, (err, result) => {
    //       if (err) throw err
    // res.json({ message: "POST work !" });
    //   });
    const jsonData = req.body;
    if (!Array.isArray(jsonData)) {
      return res.status(400).send('Data must be a JSON array.');
    } const query = 'INSERT INTO EMPLOYEE(IDEMP, NAME,BU, TIMEDRAW) VALUES ?';
    const values = jsonData.map(item => [item.IDEMP, item.NAME,item.BU, item.TIMEDRAW]);
    db.query(query, [values], (err, results) => {
      if (err) throw err;
      res.json({ message: "POST work !" });
    });
  },



  update: (req, res) => {
    const emp = req.body;
    const id = req.params.ID;
    const sqlString = "UPDATE EMPLOYEE SET ? WHERE ID = ?";
    db.query(sqlString, [emp, id], (err, result) => {
      if (err) throw err
      res.json({ message: "cập nhật nhân viên với id = " + id + " thành công" });
    });
  },
  updatetimedraw: (req, res) => {
    const emp = req.body;
    const id = req.params.ID;
    const sqlString = "UPDATE EMPLOYEE SET ? WHERE ID = ?";
    db.query(sqlString, [emp, id], (err, result) => {
      if (err) throw err
      else {
        req.params.TIMEDRAW--
        res.json({ message: "cập nhật TIMEDRAW thành công" });
      }
    });
  },

  delete: (req, res) => {
    const id = req.params.ID;
    db.query(`DELETE FROM EMPLOYEE WHERE id = ?`, id, (err, result) => {
      if (err) throw err
      res.json({ message: "xóa nhân viên với id = " + id + " thành công" });
    });
  },
};