const db = require("../common/connect");

module.exports = {
    getList: (req, res) => {
        const sqlString = "SELECT * FROM LUCKYNUMBER ";
        db.query(sqlString, (err, result) => {
            if (err) throw err
            res.json(result)
        });
    },
    getListlucky: (req, res) => {
        const sqlString = "SELECT * FROM LUCKYNUMBER WHERE STATUS = 0 ";

        db.query(sqlString, (err, result) => {
            if (err) throw err
            else {
                const sqlString_update_status = "UPDATE LUCKYNUMBER SET ? WHERE ID = ?";

                const x = Math.floor(Math.random() * result.length);
                const updateDetail = { "STATUS": "1" }
                const id = result[x].ID
                db.query(sqlString_update_status, [updateDetail, id], (err, result) => {
                    if (err) throw err
                    res.json({ message: "cập nhật số may mắn với id = " + id + " thành công" });
                });
                res.json(result[x])
            }
        });
    },
    detail: (req, res) => {
        const id = req.params.ID;
        const sqlString = "SELECT * FROM LUCKYNUMBER WHERE ID = ? ";
        db.query(sqlString, id, (err, result) => {
            if (err) throw err
            res.json(result)
            res.json({ message: "get by ID work !" });

        });
    },


    insert: (req, res) => {
        //   const emp = req.body;
        //   const sqlString = "INSERT INTO EMPLOYEE SET ?";
        //   db.query(sqlString, emp, (err, result) => {
        //       if (err) throw err
        // res.json({ message: "POST work !" });
        //   });
        const jsonData = req.body;
        if (!Array.isArray(jsonData)) {
            return res.status(400).send('Data must be a JSON array.');
        } const query = 'INSERT INTO LUCKYNUMBER(NUMB, CONTENTS, STATUS) VALUES ?';
        const values = jsonData.map(item => [item.NUMB, item.CONTENTS, item.STATUS]);
        db.query(query, [values], (err, results) => {
            if (err) throw err;
            res.json({ message: "POST work !" });
        });
    },
    update: (req, res) => {
        const emp = req.body;
        const id = req.params.ID;
        const sqlString = "UPDATE LUCKYNUMBER SET ? WHERE ID = ?";
        db.query(sqlString, [emp, id], (err, result) => {
            if (err) throw err
            res.json({ message: "cập nhật số may mắn với id = " + id + " thành công" });
        });
    },

    delete: (req, res) => {
        const id = req.params.ID;
        db.query(`DELETE FROM LUCKYNUMBER WHERE id = ?`, id, (err, result) => {
            if (err) throw err
            res.json({ message: "xóa số may mắn với id = " + id + " thành công" });
        });
    },
};